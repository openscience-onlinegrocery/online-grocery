const config = {
// custom config can go here
};

module.exports = config;
