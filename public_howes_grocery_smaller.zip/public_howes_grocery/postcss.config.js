module.exports = {
  plugins: {
    'postcss-import': {},
    'postcss-cssnext': {}
  }
}
